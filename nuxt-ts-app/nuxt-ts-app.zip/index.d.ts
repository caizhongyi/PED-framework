declare module '*.vue' {
  import Vue from 'vue'
  const _default: Vue
  export default _default
}
declare var window: Window;
declare var document: Document;
/*
declare module 'vue/types/vue' {
  interface Vue {
    $xxx: any,
  }
}*/
