module.exports=require('./lib/vue2-countdown.vue')
