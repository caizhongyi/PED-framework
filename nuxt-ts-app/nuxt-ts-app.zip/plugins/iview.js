import Vue from 'vue'
import iView from 'iview'

Vue.use(iView)